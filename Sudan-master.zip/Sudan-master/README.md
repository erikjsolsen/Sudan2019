# Sudan
##  Survey of coastal fish resources in Sudan 2012 and onwards
_1. Nov.2017_

This repository includes all R-scripts and data files used to analyse scientific survey data from three surveys along the coast of Sudan in 2012 - 2013. 
The analysis have been submitted for publication in Frontiers in Marine Science. 

To run the analysis: _sudan_catch_analyses.R_
